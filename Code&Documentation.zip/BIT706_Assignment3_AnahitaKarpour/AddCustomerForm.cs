﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class AddCustomerForm : ParentForm
    {
        public AddCustomerForm()
        {
            InitializeComponent();
        }
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                //if the input entries are correct and validated
                if (Validator.IsNameValid(txtBoxFirstName, "First name")
                && Validator.IsNameValid(txtBoxLastName, "Last name")
                && Validator.IsPhoneValid(txtBoxPhone, "Phone number"))
                {
                    string firstName = txtBoxFirstName.Text;
                    string lastName = txtBoxLastName.Text;
                    string phoneNumber = txtBoxPhone.Text;
                    bool IsStaff = ckBoxBankStaff.Checked;

                    if (controller.AddCustomer(firstName, lastName, phoneNumber, IsStaff))
                    {
                        MessageBox.Show("Customer was added successfully!", "Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Write to Binary file
                        controller.WriteBinaryData();
                        //Clear all the input
                        txtBoxFirstName.Text = "";
                        txtBoxLastName.Text = "";
                        txtBoxPhone.Text = "";
                        ckBoxBankStaff.Checked = false;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Entry Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //write the exception message to a file.
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(controller.ErrorMessage);
                }
            }
        }
    }
}


