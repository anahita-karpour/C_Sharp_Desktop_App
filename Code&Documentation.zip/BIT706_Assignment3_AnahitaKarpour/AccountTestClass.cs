﻿namespace BIT706_Assignment3_AnahitaKarpour
{
    public class AccountTestClass : Account
    {
        //public AccountTestClass(int newID)
        //{
        //}
        public AccountTestClass(int newID, Customer newOwner, decimal newBalance) : base(newID, newOwner, newBalance)
        {
        }

        public override decimal Interest()
        {
            throw new System.NotImplementedException();
        }
    }
}
