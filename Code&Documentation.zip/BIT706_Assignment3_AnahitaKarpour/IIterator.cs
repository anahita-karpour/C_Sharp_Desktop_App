﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    //Iterator interface

    public interface IIterator
    {
        Object getNext();
        bool isDone();
    }
}
