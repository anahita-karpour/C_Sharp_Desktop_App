﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class TransferForm : ParentForm, IObserver
    {
        private Customer theCustomer;
        public Customer TheCustomer { get => theCustomer; set => theCustomer = value; }

        public TransferForm()
        {
            InitializeComponent();
        }
        //Iterator pattern -
        public TransferForm(Customer customer)
        {
            TheCustomer = customer;
            InitializeComponent();
        }
        private void TransferForm_Load(object sender, EventArgs e)
        {
            DisplayCustomerName();
            Update(TheCustomer);
        }

        public void DisplayCustomerName()
        {
            lblName.Text = "";
            int id = TheCustomer.CustID;
            string firstname = TheCustomer.CustFirstName.ToString();
            string lastname = TheCustomer.CustLastName.ToString();
            bool IsStaff = TheCustomer.CustPositionStaff;
            string position;
            _ = (IsStaff ? (position = "Bank Staff") : (position = "Non-Bank Staff"));

            lblName.Text = string.Format("{0} {1} {2} ({3})", id, firstname, lastname, position);
        }

        private void BtnTransfer_Click(object sender, EventArgs e)
        {
            string inputNum = txtBoxTransferAmt.Text;       //input
            Account selectedfromAccount = null;
            Account selectedtoAccount = null;

            if (lstBoxFromAccount.SelectedItems.Count.Equals(1))
            {
                selectedfromAccount = (Account)lstBoxFromAccount.SelectedItem;
            }
            if (lstBoxToAccounts.SelectedItems.Count.Equals(1))
            {
                selectedtoAccount = (Account)lstBoxToAccounts.SelectedItem;
            }

            if (selectedtoAccount != null && selectedfromAccount != null)        //the from and the to accounts have been selected
            {
                if (selectedfromAccount != selectedtoAccount)                    //selected to and from accounts must be different
                {
                    if (Decimal.TryParse(inputNum, out decimal outNum))         //input conversion successful
                    {
                        if (controller.Transferfund(TheCustomer, selectedfromAccount, selectedtoAccount, outNum))
                        {
                            //Write to Binary file
                            controller.WriteBinaryData();
                            txtBoxTransferAmt.Text = "";
                        }
                        else
                        {
                            MessageBox.Show(controller.ErrorMessage, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //write the exception message to a file.
                            using (StreamWriter w = File.AppendText("log.txt"))
                            {
                                w.WriteLine(controller.ErrorMessage);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("'From account' must be different to 'To account' for transfering the fund", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid from and to account types.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //Iterator pattern -
        public void RefreshList()
        {
            //LstBox From Accounts
            lstBoxFromAccount.Items.Clear();
            for (IIterator it = TheCustomer.CreateIterator(); it.isDone() == false;)
            {
                lstBoxFromAccount.Items.Add((Account)it.getNext());
            }
            //LstBox To Accounts
            lstBoxToAccounts.Items.Clear();
            for (IIterator it = TheCustomer.CreateIterator(); it.isDone() == false;)
            {
                lstBoxToAccounts.Items.Add(it.getNext());
            }
        }

        public void Update(Customer customer)
        {
            RefreshList();
        }
    }
}
