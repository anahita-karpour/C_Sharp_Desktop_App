﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    [Serializable]
    public abstract class Account
    {
        //attributes
        private int iD;
        private decimal balance;
        private string strInfo;
        private Customer owner;     //to represent the association between this class(Accounts.cs) and the customer class(Customer.cs)
                                    //This allows us to know who owns the account

        //public property
        public int ID { get => iD; }
        public decimal Balance { get => balance; set => balance = value; }
        public string StrInfo { get => strInfo; set => strInfo = value; }
        public Customer Owner { get => owner; set => owner = value; }

        //Constructors
        public Account(int newID)
        {
            //default constructor; sets the unique customer number
            iD = newID;
            strInfo = "";
        }
        public Account(int newID, Customer newOwner) : this(newID)
        {
            Owner = newOwner;
        }
        public Account(int newID, Customer newOwner, decimal newBalance) : this(newID, newOwner)
        {
            Balance = newBalance;
        }

        //Methods
        /* Deposit method:
         * takes in a decimal type input value and
         * simply adds the deposited
         * amount to the balance and returns the result          
        */
        public decimal Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new Exception("Withdrawal amount must be positive");
            }
            StrInfo = String.Format("\ndeposited {0:$#,##0.00}; ", amount);//"Deposited"
            return Balance += amount;
        }

        /*CalculateInterest*/
        public abstract decimal Interest();
        /* Withdraw method:
         * takes in a decimal type input value
         * and simply deduct the requested withdrawal amount
         * from the account balance and returns the result.
         */
        public virtual decimal Withdraw(decimal withdrawalAmount)
        {
            return Balance -= withdrawalAmount;
        }
        /*Info method:
         * returns a string containing information about an account and its last transaction.
         */
        public virtual string Info()
        {
            return StrInfo + String.Format("\nBalance: {0:$#,##0.00}.", Balance) + "\nRetrieved: " + DateTime.Now;
        }
        /* ToString method:
         * overrides the ToString() method of Object class to 
         * return the Info() method of our class
        */
        public override string ToString()
        {
            return Info();
        }
    }

    /* ==========================================================
     * EveryDay account has: 
     * No interest, 
     * No overdraft limits, 
     * No fees
     * ==========================================================
     */
    [Serializable]
    public class EveryDay : Account
    {
        public EveryDay(int newID, Customer newOwner) : base(newID, newOwner) { }
        public EveryDay(int newID, Customer newOwner, decimal newBalance) : base(newID, newOwner, newBalance) { }

        public override decimal Interest()
        {
            throw new Exception("Everyday account is not an interest earning account");
        }

        /*Withdraw method
         * of the base class is overridden in this child class taking the insufficient fund case into account. 
         * If there is sufficient fund (the withdrawal amount is equal or less than the account balance) the 
         * method calls the base class Withdraw method to deduct the amount from the fund.
         * If the withdrawal amount is greater than the account balance there is insufficient fund and no 
         * amount will be deducted from the account balance. There is no fail transaction fee for this account.
         */
        public override decimal Withdraw(decimal withdrawalAmount)  //There is no fee on this account
        {
            StrInfo = String.Format("\nwithdrawal request {0:$#,##0.00}; ", withdrawalAmount); //insufficient fund
            if (Balance < withdrawalAmount)
            {
                StrInfo += "\ntransaction failed; ";
                throw new FailedWithdrawalException("Failed Transaction: Withdrawal exceeds account balance in the Everyday account.");
            }
            if (withdrawalAmount <= 0)
            {
                throw new Exception("Withdrawal amount must be positive");
            }
            StrInfo += "\ntransaction successful; ";
            return base.Withdraw(withdrawalAmount);     //call the base class Withdraw method            
        }

        /*Info method
         * of the base class is overridden in this child class by adding the account name (Everyday) and ID to the
         * base class Info method (base.Info()).
         */
        public override string Info()
        {
            return String.Format("Everyday {0}; ", ID) + base.Info();
        }
    }

    /* ==========================================================
     * Investment account has: 
     * Variable interest rate paid on all funds - It is assumed to be 4% for any balance in the Investment account 
     * Fees will incurred for failed transactions - It is assumed to be $10
     * ==========================================================
     */
    [Serializable]
    public class Investment : Account
    {
        //attributes
        private decimal investIntRate = 0.04M;
        private decimal investFailTransFee = 10;

        //properties
        public decimal InvestIntRate { get => investIntRate; set => investIntRate = value; }
        public decimal InvestFailTransFee { get => investFailTransFee; set => investFailTransFee = value; }

        //Constructor
        public Investment(int newID) : base(newID) { }
        public Investment(int newID, Customer newOwner) : base(newID, newOwner) { }
        public Investment(int newID, Customer newOwner, decimal newBalance) : base(newID, newOwner, newBalance) { }

        /* CalculateInterest method:
         * This method adds the interest obtained (according to the respective interest rate)to the balance
         * and returns the result. 
        */
        public override decimal Interest()
        {
            if (Balance <= 0)
            {
                throw new Exception("Account balance must be greater than zero to earn interest in investment account.");
            }
            StrInfo = String.Format("\nAdd interest {0:$#,##0.00}; ", (InvestIntRate * Balance));
            return Balance += InvestIntRate * Balance;
        }

        /* Withdraw method         
         */
        public override decimal Withdraw(decimal withdrawalAmount)
        {
            StrInfo = String.Format("\nwithdrawal request {0:$#,##0.00};", withdrawalAmount);
            if (withdrawalAmount > Balance)//insufficient fund/ Failed Transaction fee
            {
                StrInfo += String.Format("\ntransaction failed; fee {0:$#,##0.00}; ", (Owner.myFineStrategy.CalcFine(InvestFailTransFee)));
                Balance -= Owner.myFineStrategy.CalcFine(InvestFailTransFee);
                throw new FailedWithdrawalException("Failed Transaction: Withdrawal exceeds account balance in the Investment account.");
            }
            if (withdrawalAmount <= 0)
            {
                throw new Exception("Withdrawal amount must be positive");
            }
            StrInfo += "\ntransaction successful; ";         //sufficient fund
            return base.Withdraw(withdrawalAmount);        //calls the base class Withdraw method
        }

        /*Info method
         * of the base class is overridden in this child class by adding the account name: Investment, ID and Interest rate % to the
         * base class Info method: base.Info().
         */
        public override string Info()
        {
            return String.Format("Investment {0};\nInterest rates: {1:p} ", ID, InvestIntRate)
                + base.Info();
        }
    }

    /*============================================================
     * Omni account has:
     * Interest paid only on balance over $1000 - It is assumed to be 4%
     * Specified overdraft is permitted - It is assumed to be $100
     * Fee incured for failed transaction - It is assumed to be $10
     *============================================================
     */
    [Serializable]
    public class Omni : Account
    {
        //Attributes
        private decimal omniIntRate = 0.04M;
        private decimal overDraftLim = 100;
        private decimal omniFailTransFee = 10;

        //Properties
        /*OmniIntRate property:
         * returns the specified interest rate if the balance is greater than 1000
         * returns zero if the balance is equal and below 1000
         * Also sets the attributes omniIntRate value.
         */
        public decimal OmniIntRate
        {
            get
            {
                //since the interest is paid only on balances of over $1000
                if (Balance > 1000)
                {
                    return omniIntRate;
                }
                return 0;
            }
            set => omniIntRate = value;
        }
        public decimal OverDraftLim { get => overDraftLim; set => overDraftLim = value; }
        public decimal OmniFailTransFee { get => omniFailTransFee; set => omniFailTransFee = value; }

        //Constructor
        public Omni(int newID) : base(newID) { }
        public Omni(int newID, Customer newOwner) : base(newID, newOwner) { }
        public Omni(int newID, Customer newOwner, decimal newBalance) : base(newID, newOwner, newBalance) { }

        //Methods
        /*CalculateInterest method
         * This method adds the interest obtained to the balance
         * and returns the result(Interest is paid on Balances over 1000)
         */
        public override decimal Interest()
        {
            if (Balance <= 1000)
            {
                throw new Exception("Account balance must be above 1000 to earn interest in Omni account.");
            }
            StrInfo = String.Format("\nAdd interest {0:$#,##0.00}; ", (OmniIntRate * Balance));
            return Balance += OmniIntRate * Balance;
        }

        /*Withdraw method 
         * of the base class is overridden in this child class taking the Omni fail transaction fee and overdraft 
         * limit into account. If the withdrawal amount is greater than the account balance plus the allowed overdraft
         * limit there is insufficient fund and the specified omni fail transaction fee will be deducted.  
         * If there is sufficient fund (the withdrawal amount is equal or less than the account balance 
         * plus overdraft limit) the method calls the base class Withdraw method to deduct the amount from the fund
         */
        public override decimal Withdraw(decimal withdrawalAmount)
        {
            StrInfo = String.Format("\nwithdrawal request {0:$#,##0.00}; ", withdrawalAmount);
            if ((withdrawalAmount > Balance + OverDraftLim))  //Failed Transaction / insufficient fund
            {
                StrInfo += String.Format("\ntransaction failed; fee {0:$#,##0.00};", (Owner.myFineStrategy.CalcFine(OmniFailTransFee)));
                Balance -= Owner.myFineStrategy.CalcFine(OmniFailTransFee);
                throw new FailedWithdrawalException("Failed Transaction: withdrawal exceeds account balance plus overdraft limit in the Omni account.");
            }
            if (withdrawalAmount <= 0)
            {
                throw new Exception("Withdrawal amount must be positive");
            }
            StrInfo += "\ntransaction successful;";
            return base.Withdraw(withdrawalAmount);     //calls the base class Withdraw method
        }

        /*Info method
         * of the base class is overridden in this child class by adding the account name: Omni, ID, Interest rate % and Overdraft limit $ to the
         * base class Info method (base.Info()).
         */
        public override string Info()
        {
            return String.Format("Omni {0};\nInterest Rate {1:p};\nOverdraft Limit {2:c};", ID, (OmniIntRate), OverDraftLim)
                + base.Info();
        }

    }

}
