﻿using System;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Open the manage customer form
            Application.Run(new ManageCustomerForm());
        }
    }
}
