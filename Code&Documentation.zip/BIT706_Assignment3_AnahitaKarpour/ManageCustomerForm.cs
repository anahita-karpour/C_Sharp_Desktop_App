﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class ManageCustomerForm : ParentForm
    {
        public ManageCustomerForm()
        {
            InitializeComponent();
        }

        private void BtnManageCustAccs_Click(object sender, EventArgs e)
        {
            CustomerMenuForm frmAddCustomer = new CustomerMenuForm();
            controller.AttachObserver(frmAddCustomer);
            frmAddCustomer.Show();
        }
    }
}