﻿namespace BIT706_Assignment3_AnahitaKarpour
{
    //The partial declarations of the IObserver and ISubject interfaces
    public interface IObserver
    {
        void Update(Customer customer);
    }

    public interface ISubject
    {
        void AttachObserver(IObserver obs);
        void NotifyObservers(Customer customer);
    }
}
