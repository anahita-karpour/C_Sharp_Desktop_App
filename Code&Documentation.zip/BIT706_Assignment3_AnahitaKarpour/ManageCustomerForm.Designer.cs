﻿
namespace BIT706_Assignment3_AnahitaKarpour
{
    partial class ManageCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnManageCustAccs = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnManageCustAccs
            // 
            this.btnManageCustAccs.Location = new System.Drawing.Point(52, 135);
            this.btnManageCustAccs.Name = "btnManageCustAccs";
            this.btnManageCustAccs.Size = new System.Drawing.Size(296, 76);
            this.btnManageCustAccs.TabIndex = 1;
            this.btnManageCustAccs.Text = "Manage Customers /Customers Accounts";
            this.btnManageCustAccs.UseVisualStyleBackColor = true;
            this.btnManageCustAccs.Click += new System.EventHandler(this.BtnManageCustAccs_Click);
            // 
            // ManageCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 326);
            this.Controls.Add(this.btnManageCustAccs);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ManageCustomerForm";
            this.Text = "Customer";
            this.Controls.SetChildIndex(this.btnManageCustAccs, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnManageCustAccs;
    }
}