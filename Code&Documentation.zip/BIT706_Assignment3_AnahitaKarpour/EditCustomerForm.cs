﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class EditCustomerForm : ParentForm
    {
        private Customer theCustomer;
        public Customer TheCustomer { get => theCustomer; set => theCustomer = value; }

        public EditCustomerForm()
        {
            InitializeComponent();
        }

        private void EditCustomerForm_Load(object sender, EventArgs e)
        {
            try
            {
                //if a customer in the CustomerMenuForm listbox was selected
                if (CustomerMenuForm.selectedCustomer != (null))
                {
                    TheCustomer = CustomerMenuForm.selectedCustomer;
                    txtBoxCustID.Text = TheCustomer.CustID.ToString();
                    txtBoxFirstName.Text = TheCustomer.CustFirstName;
                    txtBoxLastName.Text = TheCustomer.CustLastName;
                    txtBoxPhone.Text = TheCustomer.CustContactNumber;
                    ckBoxBankStaff.Checked = TheCustomer.CustPositionStaff;

                    txtBoxCustID.ReadOnly = true;
                }
                else
                {
                    //Select the customerID
                    txtBoxCustID.Select();
                    DeactiveControls();
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //write the exception message to a file.
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(ee.Message);
                }
            }

        }

        private void BtnGetCust_Click(object sender, EventArgs e)
        {
            try
            {
                //if a valid int number has been entred for CustID
                if (Validator.IsPresent(txtBoxCustID, "Customer ID") && Validator.IsInt32(txtBoxCustID, "Customer ID"))
                {
                    //if a customer with that customer ID is in the list                    
                    int customerID = Convert.ToInt32(txtBoxCustID.Text);
                    if (controller.AllCustomers.Contains(controller.FindCustomerByID(customerID)))
                    {
                        //fill out the control textboxes
                        TheCustomer = controller.FindCustomerByID(customerID);
                        txtBoxFirstName.Text = TheCustomer.CustFirstName;
                        txtBoxLastName.Text = TheCustomer.CustLastName;
                        txtBoxPhone.Text = TheCustomer.CustContactNumber;
                        ckBoxBankStaff.Checked = TheCustomer.CustPositionStaff;

                        txtBoxCustID.ReadOnly = true;

                        //Activate the controls
                        txtBoxFirstName.ReadOnly = false;
                        txtBoxLastName.ReadOnly = false;
                        txtBoxPhone.ReadOnly = false;
                        ckBoxBankStaff.Enabled = true;
                    }
                    else
                    {
                        //Clear the controls
                        ClearControls();
                        throw new CustomerDoesNotExistsException("Customer with ID: " + customerID + " does not exists.");
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //write the exception message to a file.
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(ee.Message);
                }
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnEditCust_Click(object sender, EventArgs e)
        {
            try
            {
                //if a valid int number has been entred for CustID
                if (Validator.IsPresent(txtBoxCustID, "Customer ID") && Validator.IsInt32(txtBoxCustID, "Customer ID"))
                {
                    //Verify the input entries
                    if (Validator.IsNameValid(txtBoxFirstName, "firstname")
                        && Validator.IsNameValid(txtBoxLastName, "Lastname")
                        && Validator.IsPhoneValid(txtBoxPhone, "phone"))
                    {
                        if (controller.EditCustomer(TheCustomer, txtBoxFirstName.Text, txtBoxLastName.Text, txtBoxPhone.Text, ckBoxBankStaff.Checked))
                        {
                            MessageBox.Show("Customer was updated successfully!", "Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //Write to Binary file
                            controller.WriteBinaryData();
                            CustomerMenuForm.selectedCustomer = TheCustomer;
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //write the exception message to a file.
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(ee.Message);
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            const string msg = "Are you sure you want to delete this customer?";
            const string caption = "Delete customer?";

            try
            {
                //if a valid int number has been entred for CustID
                if (Validator.IsPresent(txtBoxCustID, "Customer ID") && Validator.IsInt32(txtBoxCustID, "Customer ID"))
                {
                    //if a customer with that customer ID is in the list                    
                    int customerID = Convert.ToInt32(txtBoxCustID.Text);
                    if (controller.AllCustomers.Contains(controller.FindCustomerByID(customerID)))
                    {
                        var result = MessageBox.Show(msg, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                        //if yes button was pressed
                        if (result == DialogResult.Yes)
                        {
                            if (controller.DeleteCustomer(TheCustomer))
                            {
                                ClearControls();
                                //Write to Binary file
                                controller.WriteBinaryData();
                                MessageBox.Show("Customer is deleted.", "Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                //Console.WriteLine("Customer is deleted.");
                            }
                        }
                    }
                    else
                    {
                        //Clear the controls
                        ClearControls();
                        throw new CustomerDoesNotExistsException("Customer with ID: " + customerID + " does not exists.");
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(ee.Message);
                }
            }
        }

        private void ClearControls()
        {
            //clear the controls
            txtBoxCustID.Text = "";
            txtBoxFirstName.Text = "";
            txtBoxLastName.Text = "";
            txtBoxPhone.Text = "";
            ckBoxBankStaff.Checked = false;
            txtBoxCustID.Select();
        }
        private void DeactiveControls()
        {
            //deactivate the controls
            txtBoxFirstName.ReadOnly = true;
            txtBoxLastName.ReadOnly = true;
            txtBoxPhone.ReadOnly = true;
            ckBoxBankStaff.Enabled = false;
        }

        private void EditCustomerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            CustomerMenuForm.selectedCustomer = null;
        }
    }
}


