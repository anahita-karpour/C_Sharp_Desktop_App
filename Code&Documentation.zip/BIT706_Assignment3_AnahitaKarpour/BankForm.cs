﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class BankForm : ParentForm, IObserver
    {
        private Customer theCustomer;   //an object of the Customer class
        private Account customerAccount;
        private string accountType = "";

        public Customer TheCustomer { get => theCustomer; set => theCustomer = value; }
        public Account CustomerAccount { get => customerAccount; set => customerAccount = value; }
        public string AccountType { get => accountType; set => accountType = value; }

        public BankForm()
        {
            InitializeComponent();
        }

        //Iterator pattern -
        public BankForm(Customer customer)
        {
            InitializeComponent();
            TheCustomer = customer;
        }

        private void BankForm_Load(object sender, EventArgs e)
        {
            DisplayCustomerName();
            Update(TheCustomer);
        }
        private void ComboBoxAccType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxAccType.SelectedIndex >= 0) //an account has been selected
            {
                if (comboBoxAccType.SelectedIndex.Equals(0))
                {
                    AccountType = "Everyday";
                }
                else if (comboBoxAccType.SelectedIndex.Equals(1))
                {
                    AccountType = "Investment";
                }
                else if (comboBoxAccType.SelectedIndex.Equals(2))
                {
                    AccountType = "Omni";
                }
            }
        }

        private void BtnDeposit_Click(object sender, EventArgs e)
        {
            string inputNum = txtBoxAmount.Text;        //input

            if (lstBoxAccounts.SelectedItems.Count.Equals(1))    //an account has been selected
            {
                CustomerAccount = (Account)lstBoxAccounts.SelectedItem;
                if (Decimal.TryParse(inputNum, out decimal outNum)) //input conversion successful
                {
                    if (controller.DepositFund(TheCustomer, CustomerAccount, outNum))
                    {
                        lblBalance.Text = "";
                        lblBalance.Text = "$" + CustomerAccount.Balance.ToString();
                        controller.WriteBinaryData();
                    }
                    else
                    {
                        MessageBox.Show(controller.ErrorMessage, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        //write the exception message to a file.
                        using (StreamWriter w = File.AppendText("log.txt"))
                        {
                            w.WriteLine(controller.ErrorMessage);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid account type.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnAddNewAcct_Click(object sender, EventArgs e)
        {
            string inputNum = txtBoxAmNew.Text;       //input
            if (comboBoxAccType.SelectedIndex > -1)     //an account has been selected
            {
                if (Decimal.TryParse(inputNum, out decimal outNum)) //input conversion successful
                {
                    if (outNum > 0)     //input number is positive
                    {
                        if (controller.AddCustAccounts(TheCustomer, AccountType, outNum))
                        {
                            //Write to Binary file
                            controller.WriteBinaryData();
                            txtBoxAmNew.Text = "";
                            comboBoxAccType.SelectedIndex = -1;
                        }
                        else
                        {
                            MessageBox.Show(controller.ErrorMessage, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //write the exception message to a file.
                            using (StreamWriter w = File.AppendText("log.txt"))
                            {
                                w.WriteLine(controller.ErrorMessage);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a positive number", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid amount", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid account type.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnWithdraw_Click(object sender, EventArgs e)
        {
            string inputNum = txtBoxAmount.Text;        //input

            if (lstBoxAccounts.SelectedItems.Count.Equals(1))    //an account has been selected
            {
                CustomerAccount = (Account)lstBoxAccounts.SelectedItem;
                if (Decimal.TryParse(inputNum, out decimal outNum)) //input conversion successful
                {
                    if (controller.WithdrawFund(TheCustomer, CustomerAccount, outNum))
                    {
                        lblBalance.Text = "";
                        lblBalance.Text = "$" + CustomerAccount.Balance.ToString();
                        controller.WriteBinaryData();
                    }
                    else
                    {
                        MessageBox.Show(controller.ErrorMessage, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //write the exception message to a file.
                        using (StreamWriter w = File.AppendText("log.txt"))
                        {
                            w.WriteLine(controller.ErrorMessage);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select a valid account type.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnTransfer_Click(object sender, EventArgs e)
        {
            //Iterator pattern -
            TransferForm tranfrm = new TransferForm(TheCustomer);

            //TransferForm tranfrm = new TransferForm();
            controller.AttachObserver(tranfrm);
            tranfrm.Show();
        }

        private void BtnInterest_Click(object sender, EventArgs e)
        {
            if (lstBoxAccounts.SelectedItems.Count.Equals(1))    //an account has been selected
            {
                CustomerAccount = (Account)lstBoxAccounts.SelectedItem;

                if (controller.CalculateInterest(TheCustomer, CustomerAccount))
                {
                    lblBalance.Text = "";
                    lblBalance.Text = "$" + CustomerAccount.Balance.ToString();
                    controller.WriteBinaryData();
                }
                else
                {
                    MessageBox.Show(controller.ErrorMessage, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //write the exception message to a file.
                    using (StreamWriter w = File.AppendText("log.txt"))
                    {
                        w.WriteLine(controller.ErrorMessage);
                    }
                }

            }
            else
            {
                MessageBox.Show("Please select a valid account.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void DisplayCustomerName()
        {
            lblName.Text = "";
            int id = TheCustomer.CustID;
            string firstname = TheCustomer.CustFirstName.ToString();
            string lastname = theCustomer.CustLastName.ToString();
            bool IsStaff = TheCustomer.CustPositionStaff;
            string position;
            _ = (IsStaff ? (position = "Bank Staff") : (position = "Non-Bank Staff"));

            lblName.Text = string.Format("{0} {1} {2} ({3})", id, firstname, lastname, position);
        }

        //Iterator pattern -
        public void RefreshList()
        {
            //LstBox From Accounts
            lstBoxAccounts.Items.Clear();
            for (IIterator it = TheCustomer.CreateIterator(); it.isDone() == false;)
            {
                lstBoxAccounts.Items.Add((Account)it.getNext());
            }
        }

        public void Update(Customer customer)
        {
            RefreshList();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}


