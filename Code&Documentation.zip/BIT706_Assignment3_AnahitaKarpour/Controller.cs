﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace BIT706_Assignment3_AnahitaKarpour
{
    /// <summary>
    /// The Controller class. Contains all the methods for creating and maintaining(adding, finding, editing and deleting) customer
    /// objects over different forms. Also contains all the methods for creating and maintaining(adding, depositing, withdrawaing, transferring)
    /// customer account objects over different forms.
    /// </summary>
    public class Controller : ISubject
    {
        //attributes:
        /// <summary>
        /// A list to hold the customer objects
        /// </summary>
        public List<Customer> AllCustomers = new List<Customer>();
        /// <summary>
        /// The binary data filename to read and write to. 
        /// </summary>
        private string fileName = "CustObjects.bin";
        /// <summary>
        /// A string variable to hold the value of error message.
        /// </summary>
        private string errorMessage;
        /// <summary>
        /// The collection of IObserver objects
        /// </summary>
        public List<IObserver> MyObservers = new List<IObserver>();

        //properties:
        /// <summary>
        /// Property to get and set the value of binary filename
        /// </summary>
        public string FileName { get => fileName; set => fileName = value; }
        /// <summary>
        /// Property to get the value of errorMessage
        /// </summary>
        public string ErrorMessage { get => errorMessage; }


        //methods:
        /// <summary>
        /// Creates a new customer object if it doesn't exist in the list of customers. Attaches the withdrawal 
        /// fine strategy depending on the customer occupation and adds the new customer
        /// to the list of customers. If customer does exist in the list of customers it will throw an exception.
        /// </summary>
        /// <param name="firstname">The customer first name to be added</param>
        /// <param name="lastname">The customer last name to be added</param>
        /// <param name="phone">The customer phone number to be added</param>
        /// <param name="isStaff">The customer position to be added</param>
        /// <returns>
        /// True if customer is created and added to the list successfully.
        /// Throws an exception if the customer already exists.
        /// </returns>
        /// <exception cref="CustomerAlreadyExistsException">Thrown if this customer already exists.</exception>
        public bool AddCustomer(string firstname, string lastname, string phone, bool isStaff)
        {
            if (IsCustByNameExist(firstname, lastname))
            {
                throw new CustomerAlreadyExistsException(firstname + " " + lastname + " already exists.");
            }
            Customer customer = new Customer(firstname, lastname, phone, isStaff);
            if (isStaff)    //Associating the FineStrategy
            {
                customer.SetFineStrategy(new StaffFine());
                //Console.WriteLine("staff");
            }
            else
            {
                customer.SetFineStrategy(new NonStaffFine());
                //Console.WriteLine("Non Staff");
            }
            AllCustomers.Add(customer);
            NotifyObservers(customer);  //When a new customer is successfully added then the observers need to be alerted.
                                        //This method calls the update method of each observer. It also sends a reference
                                        //to the customer that has just been added.
                                        //Console.WriteLine("Customer was added successfully!");
            return true;
        }

        /// <summary>
        /// Edits the customer first and last names, phone number and whether the customer is a staff or not
        /// if the customer is in the list of customers. It will throw an exception if the customer doesn't exsits in the list.
        /// </summary>
        /// <param name="customer">The customer to edit its details</param>
        /// <param name="firstName">The customer updated first name</param>
        /// <param name="lastName">The customer updated last name</param>
        /// <param name="phoneNumber">The customer updated phone number</param>
        /// <param name="isStaff">The customer updated position detail</param>
        /// <returns>True if the customer details were updated successfully. 
        /// It will throw an exception if the list of customer does not contain the customer.
        /// </returns>
        /// <exception cref="CustomerDoesNotExistsException">Thrown if this customer does not exist in the list of customers.</exception>
        public bool EditCustomer(Customer customer, string firstName, string lastName, string phoneNumber, bool isStaff)
        {
            if (AllCustomers.Contains(customer))
            {
                customer.CustFirstName = firstName;
                customer.CustLastName = lastName;
                customer.CustContactNumber = phoneNumber;
                customer.CustPositionStaff = isStaff;
                if (isStaff)    //Associating the FineStrategy
                {
                    customer.SetFineStrategy(new StaffFine());
                    //Console.WriteLine("staff");
                }
                else
                {
                    customer.SetFineStrategy(new NonStaffFine());
                    //Console.WriteLine("Non Staff");
                }
                //Console.WriteLine("Customer is Updated!");
                NotifyObservers(customer);
                return true;
            }
            else
            {
                //can't find the customer
                //Console.WriteLine("Can't find the customer.");
                throw new CustomerDoesNotExistsException("Customer with ID: " + customer.CustID + "does not exists.");
            }
        }

        /// <summary>
        /// Deletes the desired customer from the list of customers if the customer is in the list.
        /// It throws an exception if the customer is not in the list.
        /// </summary>
        /// <param name="customer">The customer to be deleted</param>
        /// <returns>True if the customer was found in the list and removed. It will throw an exception if the
        /// customer was not found in the list of customers.
        /// </returns>
        /// <exception cref="CustomerDoesNotExistsException">Thrown if this customer does not exist in the list of customers.</exception>
        public bool DeleteCustomer(Customer customer)
        {
            if (AllCustomers.Contains(customer))
            {
                AllCustomers.Remove(customer);
                NotifyObservers(customer);
                return true;
            }
            else
            {
                //can't find the customer
                //Console.WriteLine("Can't find the customer.");
                throw new CustomerDoesNotExistsException("Customer with ID: " + customer.CustID + "does not exists.");
            }
        }

        /// <summary>
        /// Searches the list of customers for a customer with the same given first and last names.
        /// </summary>
        /// <param name="firstName">The given customer first name to search</param>
        /// <param name="lastName">The given customer last name to search</param>
        /// <returns>True if a customer with the same first and last names are found or false if the 
        /// customer with the same first and last names could not be found.
        /// </returns>
        public bool IsCustByNameExist(string firstName, string lastName)
        {
            foreach (Customer customer in AllCustomers)
            {
                if (customer.CustLastName == lastName && customer.CustFirstName == firstName)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Searches the list of customers for a customer with the given customer ID.
        /// </summary>
        /// <param name="custID">The ID of the customer to search</param>
        /// <returns>The customer object if it was found or null if it was not found.</returns>
        public Customer FindCustomerByID(int custID)
        {
            foreach (Customer customer in AllCustomers)
            {
                if (customer.CustID == custID)
                {
                    return customer;
                }
            }
            return null;
        }

        /// <summary>
        /// Serializes the list of customers and writes them in a binary file.
        /// </summary>
        /// <returns>True if writing to the binary file was successful or false if it was not.</returns>
        public bool WriteBinaryData()
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();               //create a formatting object                
                Stream stream = new FileStream(FileName, FileMode.Create,   //Create a new IO stream to write to the *.bin file 
                    FileAccess.Write, FileShare.None);
                formatter.Serialize(stream, SingletonData.GetInstance());   //use the formatter to serialize the instance of our SingletonData class
                formatter.Serialize(stream, AllCustomers);                  //use the formatter to serialize the collection and send it to the filestream                                

                stream.Close();                                             //close the file
                return true;
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
                return false;
            }

        }

        /// <summary>
        /// Reads the binary data from the file back to the list of customer objects.
        /// </summary>
        /// <returns>True if it successfully reads the data to the list of customer objects 
        /// or will return false if the process fails.
        /// </returns>
        public bool ReadBinaryData()
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();

                //FileMode.OpenOrCreate
                Stream stream = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read,
                    FileShare.Read);

                if (stream.Length != 0)         //if the stream is not empty attemp to deserialise it
                {
                    SingletonData.SetInstance((SingletonData)formatter.Deserialize(stream));
                    AllCustomers = (List<Customer>)formatter.Deserialize(stream);
                }
                stream.Close();
                return true;
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
                return false;
            }
        }

        /// <summary>
        /// Creates an object of the account based on the input parameter and adds it to the customer's list of accounts.
        /// </summary>
        /// <param name="customer">The desired customer to create the new accout for</param>
        /// <param name="chosenAccount">The desired account to be created</param>
        /// <param name="balance">The account initial opening balance.</param>
        /// <returns>
        /// True if the account object is created and added to the list of customers successfully.
        /// It will return false if the process failed.
        /// </returns>
        public bool AddCustAccounts(Customer customer, string chosenAccount, decimal balance)
        {
            Account newAccount;

            int lastAccountIndex;
            int nextAccountIndex = 1;

            if (customer.CustAccounts.Count > 0)
            {
                lastAccountIndex = customer.CustAccounts.Count;
                nextAccountIndex = lastAccountIndex + 1;
            }
            try
            {
                if (chosenAccount.Equals("Everyday"))
                {
                    newAccount = new EveryDay(nextAccountIndex, customer, balance);
                }
                else if (chosenAccount.Equals("Investment"))
                {
                    newAccount = new Investment(nextAccountIndex, customer, balance);
                }
                else //if (chosenAccount.Equals("Omni"))
                {
                    newAccount = new Omni(nextAccountIndex, customer, balance);
                }

                customer.CustAccounts.Add(newAccount);  //Add the new account to the customer account list

                NotifyObservers(customer);
                return true;
            }
            catch (Exception ee)
            {
                errorMessage = ee.Message;
                return false;
            }
        }

        /// <summary>
        /// Deposits the input amount into the customer's chosen account.
        /// </summary>
        /// <param name="customer">The desired customer</param>
        /// <param name="account">The account to deposit the fund into</param>
        /// <param name="amount">The amount to be deposited</param>
        /// <returns>True if the depositing process was successful or false if it was not successful.</returns>
        public bool DepositFund(Customer customer, Account account, decimal amount)
        {
            try
            {
                account.Deposit(amount);
                NotifyObservers(customer);
                return true;
            }
            catch (Exception ee)
            {
                errorMessage = ee.Message;
                return false;
            }
        }

        /// <summary>
        /// Withdraws the desired amount from the customer's chosen account.
        /// </summary>
        /// <param name="customer">The desire customer</param>
        /// <param name="account">The account to withdraw fund from</param>
        /// <param name="amount">The withdrawal amount</param>
        /// <returns>True if the withdarawal was successful or false if the process failed.</returns>
        /// <exception cref="FailedWithdrawalException">Thrown if not enough fund is available to complete the transaction.</exception>
        public bool WithdrawFund(Customer customer, Account account, decimal amount)
        {
            try
            {
                account.Withdraw(amount);
                NotifyObservers(customer);
                return true;
            }
            catch (FailedWithdrawalException e)
            {
                errorMessage = e.Message;
                NotifyObservers(customer);
                return false;
            }
            catch (Exception ee)
            {
                errorMessage = ee.Message;
                return false;
            }
        }

        /// <summary>
        /// Calculates the interest earned on an account.
        /// </summary>
        /// <param name="customer">The desired customer the account belongs to.</param>
        /// <param name="account">The account to calculate the interest for.</param>
        /// <returns>True if calculating interest for the specified account was successful or false if 
        /// it was not successful.</returns>
        /// <exception cref="Exception">Thrown if the account is not an interest earning account.</exception>
        public bool CalculateInterest(Customer customer, Account account)
        {
            try
            {
                account.Interest();
                NotifyObservers(customer);
                return true;
            }
            catch (Exception ee)
            {
                errorMessage = ee.Message;
                return false;
            }
        }

        /// <summary>
        /// Transfers fund from one account to another account of the same customer. 
        /// </summary>
        /// <param name="customer">The desired customer the fund transfer is to take place for.</param>
        /// <param name="fromAccount">The account the fund to be taken out of.</param>
        /// <param name="toAccount">The account the fund to be deposited to.</param>
        /// <param name="amount">The amount to be transferred between accounts.</param>
        /// <returns>True if the transfer is successful and false if it is not.</returns>
        /// <exception cref="FailedWithdrawalException">Thrown if there is not enough fund in the account the fund is to be taken out of.</exception>
        public bool Transferfund(Customer customer, Account fromAccount, Account toAccount, decimal amount)
        {
            try
            {
                fromAccount.Balance = fromAccount.Withdraw(amount);
                toAccount.Balance = toAccount.Deposit(amount);
                NotifyObservers(customer);
                return true;
            }
            catch (FailedWithdrawalException e)
            {
                errorMessage = e.Message;
                NotifyObservers(customer);
                return false;
            }
            catch (Exception ee)
            {
                errorMessage = ee.Message;
                return false;
            }
        }

        /// <summary>
        /// Adds the input observer to the collection of MyObservers
        /// </summary>
        /// <param name="obs">an IObserver object</param>
        public void AttachObserver(IObserver obs)
        {
            MyObservers.Add(obs);
        }

        /// <summary>
        /// Calls the Update() method of each observer and sends a reference to the customer object. 
        /// </summary>
        /// <param name="cust">An object of the customer class</param>
        public void NotifyObservers(Customer cust)
        {
            foreach (IObserver obs in MyObservers)
            {
                obs.Update(cust);
            }
        }

    }
}