﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public class CustomerAlreadyExistsException : Exception
    {
        public CustomerAlreadyExistsException()
        {
        }

        public CustomerAlreadyExistsException(string message) : base(message)
        {
        }
    }
}
