﻿using System;
using System.Collections.Generic;

namespace BIT706_Assignment3_AnahitaKarpour
{
    [Serializable]
    public class Customer
    {
        //attributes
        private readonly int custID;
        private string custFirstName;
        private string custLastName;
        private string custContactNumber;
        private bool custPositionStaff; //is true if the customer is a staff
        private List<Account> custAccounts = new List<Account>();   //to represent the association between this class(Customer.cs) and the account class(Account.cs)
                                                                    //This allows us to know the list of accounts a Customer owns
                                                                    //public property
        public int CustID { get => custID; }    //CustID is read only. It can't be set to a new value.
        public string CustFirstName { get => custFirstName; set => custFirstName = value; }
        public string CustLastName { get => custLastName; set => custLastName = value; }
        public string CustContactNumber { get => custContactNumber; set => custContactNumber = value; }
        public bool CustPositionStaff { get => custPositionStaff; set => custPositionStaff = value; }
        public List<Account> CustAccounts { get => custAccounts; set => custAccounts = value; }

        public IFineStrategy myFineStrategy;                    //customer objects are associated with a strategy object.
                                                                //We don't know which type of strategy yet, so we associate
                                                                //the Customer with an object of the IFineStrategy interface.
        public IIterator CreateIterator()
        {
            return new AccountIterator(this);
        }

        //Constructors
        //Default constructor; sets the unique customer number
        public Customer()
        {
            custID = SingletonData.NextId;                  //unique customer number is set using the Singleton design pattern
        }
        public Customer(string newFirstName, string newLastName, string newContact) : this()
        {
            CustFirstName = newFirstName;
            CustLastName = newLastName;
            CustContactNumber = newContact;
        }
        public Customer(string newFirstName, string newLastName, string newContact, bool newPosition) : this(newFirstName, newLastName, newContact)
        {
            CustPositionStaff = newPosition;
        }
        public Customer(string newFirstName, string newLastName, string newContact, bool newPosition, List<Account> newAccounts) : this(newFirstName, newLastName, newContact, newPosition)
        {
            CustAccounts = newAccounts;
        }

        //To set the particular strategy. 
        public void SetFineStrategy(IFineStrategy newStrategy)
        {
            myFineStrategy = newStrategy;
        }

        /*Info() method:
         * returns a string containing all the information about the customer.
         */
        public string Info()
        {
            string strInfo = CustID + "- " + CustFirstName + " " + CustLastName + "; phone number: " + CustContactNumber +
                "; bank staff position:" + CustPositionStaff + "; customer accounts:";

            foreach (Account account in CustAccounts)
            {
                strInfo += account + "; ";
            }
            return strInfo;
        }
        /* ToString method:
        * overrides the ToString() method of Object class to 
        * return the Info() method of our class
        */
        public override string ToString()
        {
            return Info();
        }
    }
}

