﻿namespace BIT706_Assignment3_AnahitaKarpour
{
    public class AccountIterator : IIterator
    {
        private Customer cust;
        private int currentIndex;
        public AccountIterator(Customer customer)
        {
            cust = customer;
            currentIndex = 0;
        }
        public object getNext()
        {
            if (!isDone()) { return cust.CustAccounts[currentIndex++]; }
            return null;
        }

        public bool isDone()
        {
            if (currentIndex < cust.CustAccounts.Count) { return false; }
            return true;
        }
    }
    //public class CustomerIterator : IIterator
    //{
    //    //private Customer cust;
    //    private Customer cust;
    //    private int currentIndex;
    //    public CustomerIterator(Customer customer)
    //    {
    //        cust = customer;
    //        currentIndex = 0;
    //    }
    //    public object getNext()
    //    {
    //        if (!isDone()) { return cust.[currentIndex++]; }
    //        return null;
    //    }

    //    public bool isDone()
    //    {
    //        if (currentIndex < cust.CustID) { return false; }
    //        return true;
    //    }
    //}
}
