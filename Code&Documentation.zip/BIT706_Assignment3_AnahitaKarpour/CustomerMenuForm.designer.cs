﻿
namespace BIT706_Assignment3_AnahitaKarpour
{
    partial class CustomerMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstBoxCustomer = new System.Windows.Forms.ListBox();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.btnEditSelectedCustomer = new System.Windows.Forms.Button();
            this.btnAccounts = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstBoxCustomer
            // 
            this.lstBoxCustomer.FormattingEnabled = true;
            this.lstBoxCustomer.HorizontalExtent = 100000;
            this.lstBoxCustomer.HorizontalScrollbar = true;
            this.lstBoxCustomer.ItemHeight = 18;
            this.lstBoxCustomer.Location = new System.Drawing.Point(13, 61);
            this.lstBoxCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.lstBoxCustomer.Name = "lstBoxCustomer";
            this.lstBoxCustomer.ScrollAlwaysVisible = true;
            this.lstBoxCustomer.Size = new System.Drawing.Size(571, 310);
            this.lstBoxCustomer.TabIndex = 0;
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddCustomer.Location = new System.Drawing.Point(13, 389);
            this.btnAddCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(117, 45);
            this.btnAddCustomer.TabIndex = 1;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.BtnAddCustomer_Click);
            // 
            // btnEditSelectedCustomer
            // 
            this.btnEditSelectedCustomer.Location = new System.Drawing.Point(138, 389);
            this.btnEditSelectedCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditSelectedCustomer.Name = "btnEditSelectedCustomer";
            this.btnEditSelectedCustomer.Size = new System.Drawing.Size(168, 45);
            this.btnEditSelectedCustomer.TabIndex = 2;
            this.btnEditSelectedCustomer.Text = "Edit/ Delete Customer";
            this.btnEditSelectedCustomer.UseVisualStyleBackColor = true;
            this.btnEditSelectedCustomer.Click += new System.EventHandler(this.BtnEditSelectedCustomer_Click);
            // 
            // btnAccounts
            // 
            this.btnAccounts.Location = new System.Drawing.Point(313, 389);
            this.btnAccounts.Name = "btnAccounts";
            this.btnAccounts.Size = new System.Drawing.Size(271, 45);
            this.btnAccounts.TabIndex = 4;
            this.btnAccounts.Text = "Manage Selected Customer Accounts";
            this.btnAccounts.UseVisualStyleBackColor = true;
            this.btnAccounts.Click += new System.EventHandler(this.BtnAccounts_Click);
            // 
            // CustomerMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 455);
            this.Controls.Add(this.btnAccounts);
            this.Controls.Add(this.btnEditSelectedCustomer);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.lstBoxCustomer);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "CustomerMenuForm";
            this.Text = "Display Customer";
            this.Load += new System.EventHandler(this.DisplayCustomerForm_Load);
            this.Controls.SetChildIndex(this.lstBoxCustomer, 0);
            this.Controls.SetChildIndex(this.btnAddCustomer, 0);
            this.Controls.SetChildIndex(this.btnEditSelectedCustomer, 0);
            this.Controls.SetChildIndex(this.btnAccounts, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstBoxCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button btnEditSelectedCustomer;
        private System.Windows.Forms.Button btnAccounts;
    }
}