﻿
namespace BIT706_Assignment3_AnahitaKarpour
{
    partial class EditCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ckBoxBankStaff = new System.Windows.Forms.CheckBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtBoxPhone = new System.Windows.Forms.TextBox();
            this.txtBoxLastName = new System.Windows.Forms.TextBox();
            this.txtBoxFirstName = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblCustID = new System.Windows.Forms.Label();
            this.txtBoxCustID = new System.Windows.Forms.TextBox();
            this.btnGetCust = new System.Windows.Forms.Button();
            this.btnEditCust = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ckBoxBankStaff
            // 
            this.ckBoxBankStaff.AutoSize = true;
            this.ckBoxBankStaff.Location = new System.Drawing.Point(184, 227);
            this.ckBoxBankStaff.Name = "ckBoxBankStaff";
            this.ckBoxBankStaff.Size = new System.Drawing.Size(95, 22);
            this.ckBoxBankStaff.TabIndex = 17;
            this.ckBoxBankStaff.Text = "Bank Staff";
            this.ckBoxBankStaff.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(327, 268);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(145, 61);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Cancel/ Close";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // txtBoxPhone
            // 
            this.txtBoxPhone.Location = new System.Drawing.Point(184, 197);
            this.txtBoxPhone.Name = "txtBoxPhone";
            this.txtBoxPhone.Size = new System.Drawing.Size(288, 24);
            this.txtBoxPhone.TabIndex = 15;
            // 
            // txtBoxLastName
            // 
            this.txtBoxLastName.Location = new System.Drawing.Point(184, 160);
            this.txtBoxLastName.Name = "txtBoxLastName";
            this.txtBoxLastName.Size = new System.Drawing.Size(288, 24);
            this.txtBoxLastName.TabIndex = 14;
            // 
            // txtBoxFirstName
            // 
            this.txtBoxFirstName.Location = new System.Drawing.Point(184, 118);
            this.txtBoxFirstName.Name = "txtBoxFirstName";
            this.txtBoxFirstName.Size = new System.Drawing.Size(288, 24);
            this.txtBoxFirstName.TabIndex = 13;
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(15, 200);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(109, 18);
            this.lblPhoneNumber.TabIndex = 12;
            this.lblPhoneNumber.Text = "Phone number:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(15, 163);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(81, 18);
            this.lblLastName.TabIndex = 11;
            this.lblLastName.Text = "Last name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(18, 121);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(82, 18);
            this.lblFirstName.TabIndex = 10;
            this.lblFirstName.Text = "First name:";
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Location = new System.Drawing.Point(21, 46);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(96, 18);
            this.lblCustID.TabIndex = 18;
            this.lblCustID.Text = "Customer ID:";
            // 
            // txtBoxCustID
            // 
            this.txtBoxCustID.Location = new System.Drawing.Point(184, 43);
            this.txtBoxCustID.Name = "txtBoxCustID";
            this.txtBoxCustID.Size = new System.Drawing.Size(148, 24);
            this.txtBoxCustID.TabIndex = 19;
            // 
            // btnGetCust
            // 
            this.btnGetCust.Location = new System.Drawing.Point(338, 40);
            this.btnGetCust.Name = "btnGetCust";
            this.btnGetCust.Size = new System.Drawing.Size(134, 31);
            this.btnGetCust.TabIndex = 20;
            this.btnGetCust.Text = "Get Customer";
            this.btnGetCust.UseVisualStyleBackColor = true;
            this.btnGetCust.Click += new System.EventHandler(this.BtnGetCust_Click);
            // 
            // btnEditCust
            // 
            this.btnEditCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCust.Location = new System.Drawing.Point(18, 268);
            this.btnEditCust.Name = "btnEditCust";
            this.btnEditCust.Size = new System.Drawing.Size(134, 61);
            this.btnEditCust.TabIndex = 21;
            this.btnEditCust.Text = "Edit Customer";
            this.btnEditCust.UseVisualStyleBackColor = true;
            this.btnEditCust.Click += new System.EventHandler(this.BtnEditCust_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDelete.Location = new System.Drawing.Point(171, 268);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(137, 61);
            this.BtnDelete.TabIndex = 22;
            this.BtnDelete.Text = "Delete Customer";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // EditCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 341);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.btnEditCust);
            this.Controls.Add(this.btnGetCust);
            this.Controls.Add(this.txtBoxCustID);
            this.Controls.Add(this.lblCustID);
            this.Controls.Add(this.ckBoxBankStaff);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtBoxPhone);
            this.Controls.Add(this.txtBoxLastName);
            this.Controls.Add(this.txtBoxFirstName);
            this.Controls.Add(this.lblPhoneNumber);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblFirstName);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "EditCustomerForm";
            this.Text = "Edit/ Delete Customer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EditCustomerForm_FormClosing);
            this.Load += new System.EventHandler(this.EditCustomerForm_Load);
            this.Controls.SetChildIndex(this.lblFirstName, 0);
            this.Controls.SetChildIndex(this.lblLastName, 0);
            this.Controls.SetChildIndex(this.lblPhoneNumber, 0);
            this.Controls.SetChildIndex(this.txtBoxFirstName, 0);
            this.Controls.SetChildIndex(this.txtBoxLastName, 0);
            this.Controls.SetChildIndex(this.txtBoxPhone, 0);
            this.Controls.SetChildIndex(this.btnCancel, 0);
            this.Controls.SetChildIndex(this.ckBoxBankStaff, 0);
            this.Controls.SetChildIndex(this.lblCustID, 0);
            this.Controls.SetChildIndex(this.txtBoxCustID, 0);
            this.Controls.SetChildIndex(this.btnGetCust, 0);
            this.Controls.SetChildIndex(this.btnEditCust, 0);
            this.Controls.SetChildIndex(this.BtnDelete, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ckBoxBankStaff;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtBoxPhone;
        private System.Windows.Forms.TextBox txtBoxLastName;
        private System.Windows.Forms.TextBox txtBoxFirstName;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.TextBox txtBoxCustID;
        private System.Windows.Forms.Button btnGetCust;
        private System.Windows.Forms.Button btnEditCust;
        private System.Windows.Forms.Button BtnDelete;
    }
}