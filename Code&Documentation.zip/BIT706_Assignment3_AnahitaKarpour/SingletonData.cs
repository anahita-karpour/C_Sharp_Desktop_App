﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    //SingletonData class is a singleton pattern to ensure there is only one object created for the class
    [Serializable]
    class SingletonData
    {
        private int nextId;
        //a variable that is an instance of the class itself
        //This static variable is the only object we will have of the SingletonData class
        private static SingletonData myInstance;

        //1- We need to prevent any other instance being created
        //This is done by making the constructor for the class private
        private SingletonData() { }

        //2- We need to make the static variable myInstance (the only object we will ever have of 
        //the SingletonData class) available to other classes 
        //We do this by providing a public static method with a signature
        public static SingletonData GetInstance()
        {
            //when we ask for the instance, if there is one then that is returned.
            //if there is none then we create the intance and return that
            if (myInstance == null)
            {
                myInstance = new SingletonData();
            }

            return myInstance;
        }

        //Making our class update and return the nextID
        //we do that by creating a public property get method NextId
        public static int NextId
        {
            get
            {
                GetInstance();
                //it increments it
                myInstance.nextId++;
                //returns myInstance value of nextId
                return myInstance.nextId;
            }
        }

        public static void SetInstance(SingletonData s)
        {
            myInstance = s;
        }

    }
}


