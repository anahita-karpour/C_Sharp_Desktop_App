﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{

    public interface IFineStrategy
    {
        decimal CalcFine(decimal fine);
    }

    [Serializable]
    public class StaffFine : IFineStrategy
    {
        public decimal CalcFine(decimal fine)
        {
            return (fine * 0.5M);
        }
    }
    [Serializable]
    public class NonStaffFine : IFineStrategy
    {
        public decimal CalcFine(decimal fine)
        {
            return fine;
        }
    }
}

