﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    class CustomerDoesNotExistsException : Exception
    {
        public CustomerDoesNotExistsException()
        {
        }

        public CustomerDoesNotExistsException(string message) : base(message)
        {
        }
    }
}
