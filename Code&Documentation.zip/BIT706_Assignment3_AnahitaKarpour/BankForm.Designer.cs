﻿
namespace BIT706_Assignment3_AnahitaKarpour
{
    partial class BankForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeposit = new System.Windows.Forms.Button();
            this.btnWithdraw = new System.Windows.Forms.Button();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpBox = new System.Windows.Forms.GroupBox();
            this.btnInterest = new System.Windows.Forms.Button();
            this.txtBoxAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblBalanceText = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lstBoxAccounts = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBoxAmNew = new System.Windows.Forms.TextBox();
            this.lblAmNewAccount = new System.Windows.Forms.Label();
            this.comboBoxAccType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BtnAddNewAcct = new System.Windows.Forms.Button();
            this.grpBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDeposit
            // 
            this.btnDeposit.Location = new System.Drawing.Point(158, 133);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(142, 38);
            this.btnDeposit.TabIndex = 3;
            this.btnDeposit.Text = "Deposit";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.BtnDeposit_Click);
            // 
            // btnWithdraw
            // 
            this.btnWithdraw.Location = new System.Drawing.Point(158, 84);
            this.btnWithdraw.Name = "btnWithdraw";
            this.btnWithdraw.Size = new System.Drawing.Size(142, 41);
            this.btnWithdraw.TabIndex = 4;
            this.btnWithdraw.Text = "Withdraw";
            this.btnWithdraw.UseVisualStyleBackColor = true;
            this.btnWithdraw.Click += new System.EventHandler(this.BtnWithdraw_Click);
            // 
            // btnTransfer
            // 
            this.btnTransfer.Location = new System.Drawing.Point(16, 133);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(137, 38);
            this.btnTransfer.TabIndex = 5;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.BtnTransfer_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(16, 175);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(137, 40);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.DarkRed;
            this.lblName.Location = new System.Drawing.Point(18, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 20);
            this.lblName.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(274, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Manage Accounts";
            // 
            // grpBox
            // 
            this.grpBox.Controls.Add(this.btnCancel);
            this.grpBox.Controls.Add(this.btnInterest);
            this.grpBox.Controls.Add(this.txtBoxAmount);
            this.grpBox.Controls.Add(this.btnTransfer);
            this.grpBox.Controls.Add(this.label2);
            this.grpBox.Controls.Add(this.lblBalanceText);
            this.grpBox.Controls.Add(this.lblBalance);
            this.grpBox.Controls.Add(this.btnWithdraw);
            this.grpBox.Controls.Add(this.btnDeposit);
            this.grpBox.Location = new System.Drawing.Point(356, 313);
            this.grpBox.Name = "grpBox";
            this.grpBox.Size = new System.Drawing.Size(312, 228);
            this.grpBox.TabIndex = 17;
            this.grpBox.TabStop = false;
            this.grpBox.Text = "Transaction";
            // 
            // btnInterest
            // 
            this.btnInterest.Location = new System.Drawing.Point(16, 85);
            this.btnInterest.Name = "btnInterest";
            this.btnInterest.Size = new System.Drawing.Size(137, 40);
            this.btnInterest.TabIndex = 9;
            this.btnInterest.Text = "Calculate Interest";
            this.btnInterest.UseVisualStyleBackColor = true;
            this.btnInterest.Click += new System.EventHandler(this.BtnInterest_Click);
            // 
            // txtBoxAmount
            // 
            this.txtBoxAmount.Location = new System.Drawing.Point(158, 23);
            this.txtBoxAmount.Name = "txtBoxAmount";
            this.txtBoxAmount.Size = new System.Drawing.Size(142, 24);
            this.txtBoxAmount.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(11, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Amount";
            // 
            // lblBalanceText
            // 
            this.lblBalanceText.AutoSize = true;
            this.lblBalanceText.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblBalanceText.Location = new System.Drawing.Point(11, 50);
            this.lblBalanceText.Name = "lblBalanceText";
            this.lblBalanceText.Size = new System.Drawing.Size(65, 18);
            this.lblBalanceText.TabIndex = 15;
            this.lblBalanceText.Text = "Balance:";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblBalance.Location = new System.Drawing.Point(155, 50);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(13, 18);
            this.lblBalance.TabIndex = 12;
            this.lblBalance.Text = "-";
            // 
            // lstBoxAccounts
            // 
            this.lstBoxAccounts.FormattingEnabled = true;
            this.lstBoxAccounts.HorizontalExtent = 10000;
            this.lstBoxAccounts.HorizontalScrollbar = true;
            this.lstBoxAccounts.ItemHeight = 18;
            this.lstBoxAccounts.Location = new System.Drawing.Point(13, 87);
            this.lstBoxAccounts.Margin = new System.Windows.Forms.Padding(4);
            this.lstBoxAccounts.Name = "lstBoxAccounts";
            this.lstBoxAccounts.ScrollAlwaysVisible = true;
            this.lstBoxAccounts.Size = new System.Drawing.Size(336, 454);
            this.lstBoxAccounts.TabIndex = 18;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBoxAmNew);
            this.groupBox1.Controls.Add(this.lblAmNewAccount);
            this.groupBox1.Controls.Add(this.comboBoxAccType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.BtnAddNewAcct);
            this.groupBox1.Location = new System.Drawing.Point(356, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(312, 229);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add New Account";
            // 
            // txtBoxAmNew
            // 
            this.txtBoxAmNew.Location = new System.Drawing.Point(117, 75);
            this.txtBoxAmNew.Name = "txtBoxAmNew";
            this.txtBoxAmNew.Size = new System.Drawing.Size(183, 24);
            this.txtBoxAmNew.TabIndex = 17;
            // 
            // lblAmNewAccount
            // 
            this.lblAmNewAccount.AutoSize = true;
            this.lblAmNewAccount.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblAmNewAccount.Location = new System.Drawing.Point(13, 78);
            this.lblAmNewAccount.Name = "lblAmNewAccount";
            this.lblAmNewAccount.Size = new System.Drawing.Size(59, 18);
            this.lblAmNewAccount.TabIndex = 16;
            this.lblAmNewAccount.Text = "Amount";
            // 
            // comboBoxAccType
            // 
            this.comboBoxAccType.FormattingEnabled = true;
            this.comboBoxAccType.Items.AddRange(new object[] {
            "Everyday",
            "Investment",
            "Omni"});
            this.comboBoxAccType.Location = new System.Drawing.Point(117, 31);
            this.comboBoxAccType.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxAccType.Name = "comboBoxAccType";
            this.comboBoxAccType.Size = new System.Drawing.Size(183, 26);
            this.comboBoxAccType.TabIndex = 1;
            this.comboBoxAccType.SelectedIndexChanged += new System.EventHandler(this.ComboBoxAccType_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(7, 34);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "Account Type";
            // 
            // BtnAddNewAcct
            // 
            this.BtnAddNewAcct.Location = new System.Drawing.Point(158, 120);
            this.BtnAddNewAcct.Name = "BtnAddNewAcct";
            this.BtnAddNewAcct.Size = new System.Drawing.Size(142, 41);
            this.BtnAddNewAcct.TabIndex = 2;
            this.BtnAddNewAcct.Text = "Add New Account";
            this.BtnAddNewAcct.UseVisualStyleBackColor = true;
            this.BtnAddNewAcct.Click += new System.EventHandler(this.BtnAddNewAcct_Click);
            // 
            // BankForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(699, 568);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lstBoxAccounts);
            this.Controls.Add(this.grpBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblName);
            this.Name = "BankForm";
            this.Text = "BankForm";
            this.Load += new System.EventHandler(this.BankForm_Load);
            this.Controls.SetChildIndex(this.lblName, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.grpBox, 0);
            this.Controls.SetChildIndex(this.lstBoxAccounts, 0);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.grpBox.ResumeLayout(false);
            this.grpBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDeposit;
        private System.Windows.Forms.Button btnWithdraw;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpBox;
        private System.Windows.Forms.TextBox txtBoxAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblBalanceText;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.ListBox lstBoxAccounts;
        private System.Windows.Forms.Button btnInterest;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtBoxAmNew;
        private System.Windows.Forms.Label lblAmNewAccount;
        private System.Windows.Forms.ComboBox comboBoxAccType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BtnAddNewAcct;
    }
}