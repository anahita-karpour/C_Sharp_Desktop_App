﻿using System;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class ParentForm : Form
    {
        //static controller variable
        public static Controller controller = new Controller();

        public ParentForm()
        {
            InitializeComponent();
        }

        private void ParentForm_Load(object sender, EventArgs e)
        {

        }
    }
}