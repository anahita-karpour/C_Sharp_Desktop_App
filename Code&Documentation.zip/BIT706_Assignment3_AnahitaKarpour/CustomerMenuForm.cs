﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public partial class CustomerMenuForm : ParentForm, IObserver
    {
        public static Customer selectedCustomer = null;

        public CustomerMenuForm()
        {
            InitializeComponent();
        }

        private void BtnAddCustomer_Click(object sender, EventArgs e)
        {
            AddCustomerForm frmAddCustomer = new AddCustomerForm();
            frmAddCustomer.Show();
        }

        private void BtnEditSelectedCustomer_Click(object sender, EventArgs e)
        {
            //if an item of the listbox is selected
            if (lstBoxCustomer.SelectedItems.Count.Equals(1))
            {
                selectedCustomer = (Customer)lstBoxCustomer.SelectedItem;
            }
            EditCustomerForm frmEditCustomer = new EditCustomerForm();
            frmEditCustomer.Show();
        }

        private void DisplayCustomerForm_Load(object sender, EventArgs e)
        {
            //to display the horizontal scroll bar - the scroll bar only appears when it is necessary
            lstBoxCustomer.HorizontalScrollbar = true;

            //Clear the listbox
            lstBoxCustomer.Items.Clear();
            //Read the customers data into AllCustomer list
            //or if error occured write the reason the log.txt file
            if (!controller.ReadBinaryData())
            {
                using (StreamWriter w = File.AppendText("log.txt"))
                {
                    w.WriteLine(controller.ErrorMessage);
                }
            }
            //Display the list of customers in the listbox
            DisplayCustomers();
        }

        public void DisplayCustomers()
        {
            foreach (Customer c in controller.AllCustomers)
            {
                lstBoxCustomer.Items.Add(c);
            }
        }

        private void BtnAccounts_Click(object sender, EventArgs e)
        {
            if (lstBoxCustomer.SelectedItems.Count.Equals(1))
            {
                selectedCustomer = (Customer)lstBoxCustomer.SelectedItem;
                //Console.WriteLine(selectedCustomer);

                //Iterator pattern -
                BankForm frmCustAccount = new BankForm(selectedCustomer);

                //Attching the form as an observer of the controller class
                controller.AttachObserver(frmCustAccount);
                frmCustAccount.Show();
            }
            else
            {
                MessageBox.Show("Please select a customer!");
            }

        }

        //IObserver interface implemented Update() method
        public void Update(Customer customer)
        {
            lstBoxCustomer.Items.Clear();
            foreach (Customer cust in controller.AllCustomers)
                lstBoxCustomer.Items.Add(cust);
        }
    }
}
