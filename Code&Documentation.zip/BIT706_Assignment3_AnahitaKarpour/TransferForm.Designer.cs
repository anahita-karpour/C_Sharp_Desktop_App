﻿
namespace BIT706_Assignment3_AnahitaKarpour
{
    partial class TransferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstBoxToAccounts = new System.Windows.Forms.ListBox();
            this.txtBoxTransferAmt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstBoxFromAccount = new System.Windows.Forms.ListBox();
            this.lblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstBoxToAccounts);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(612, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(334, 454);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "To Account";
            // 
            // lstBoxToAccounts
            // 
            this.lstBoxToAccounts.FormattingEnabled = true;
            this.lstBoxToAccounts.HorizontalExtent = 5000;
            this.lstBoxToAccounts.HorizontalScrollbar = true;
            this.lstBoxToAccounts.ItemHeight = 18;
            this.lstBoxToAccounts.Location = new System.Drawing.Point(21, 33);
            this.lstBoxToAccounts.Margin = new System.Windows.Forms.Padding(4);
            this.lstBoxToAccounts.Name = "lstBoxToAccounts";
            this.lstBoxToAccounts.ScrollAlwaysVisible = true;
            this.lstBoxToAccounts.Size = new System.Drawing.Size(290, 400);
            this.lstBoxToAccounts.TabIndex = 19;
            // 
            // txtBoxTransferAmt
            // 
            this.txtBoxTransferAmt.Location = new System.Drawing.Point(387, 148);
            this.txtBoxTransferAmt.Name = "txtBoxTransferAmt";
            this.txtBoxTransferAmt.Size = new System.Drawing.Size(204, 24);
            this.txtBoxTransferAmt.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(384, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Amount";
            // 
            // btnTransfer
            // 
            this.btnTransfer.Location = new System.Drawing.Point(387, 189);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(204, 38);
            this.btnTransfer.TabIndex = 5;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.BtnTransfer_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstBoxFromAccount);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(18, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(334, 454);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "From Account";
            // 
            // lstBoxFromAccount
            // 
            this.lstBoxFromAccount.FormattingEnabled = true;
            this.lstBoxFromAccount.HorizontalExtent = 5000;
            this.lstBoxFromAccount.HorizontalScrollbar = true;
            this.lstBoxFromAccount.ItemHeight = 18;
            this.lstBoxFromAccount.Location = new System.Drawing.Point(26, 33);
            this.lstBoxFromAccount.Margin = new System.Windows.Forms.Padding(4);
            this.lstBoxFromAccount.Name = "lstBoxFromAccount";
            this.lstBoxFromAccount.ScrollAlwaysVisible = true;
            this.lstBoxFromAccount.Size = new System.Drawing.Size(287, 400);
            this.lstBoxFromAccount.TabIndex = 19;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.DarkRed;
            this.lblName.Location = new System.Drawing.Point(14, 42);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 20);
            this.lblName.TabIndex = 25;
            // 
            // TransferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 568);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtBoxTransferAmt);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.label3);
            this.Name = "TransferForm";
            this.Text = "Transfer Between Accounts";
            this.Load += new System.EventHandler(this.TransferForm_Load);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.btnTransfer, 0);
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.Controls.SetChildIndex(this.txtBoxTransferAmt, 0);
            this.Controls.SetChildIndex(this.groupBox2, 0);
            this.Controls.SetChildIndex(this.lblName, 0);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstBoxToAccounts;
        private System.Windows.Forms.TextBox txtBoxTransferAmt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstBoxFromAccount;
        private System.Windows.Forms.Label lblName;
    }
}