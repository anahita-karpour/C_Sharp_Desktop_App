﻿using System;

namespace BIT706_Assignment3_AnahitaKarpour
{
    public class FailedWithdrawalException : Exception
    {
        public FailedWithdrawalException()
        {
        }

        public FailedWithdrawalException(string message) : base(message)
        {
        }
    }
}
