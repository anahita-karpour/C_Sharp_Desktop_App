﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace BIT706_Assignment3_AnahitaKarpour
{
    /* Validator Class:
    * Validates the Windows form inputs before storing them in the program.
    */
    public class Validator
    {
        public Validator() { }

        public static bool IsPresent(Control control, string name)
        {
            if (control.GetType().ToString() == "System.Windows.Forms.TextBox")
            {
                if (control.Text == "")
                {
                    control.Focus();
                    throw new Exception(name + " is a required field.");
                }
            }
            return true;
        }

        public static bool IsInt32(Control control, string name)
        {
            if (int.TryParse(control.Text, out _))
            {
                //Convert.ToInt32(control.Text) != null)
                return true;
            }
            //Console.WriteLine("Enter a valid integer.");
            throw new Exception(name + " input entry must be a valid integer.");
        }

        public static bool IsNameValid(Control control, string name)
        {
            //Validating user input with Regular Expression
            //Defining a regular expression pattern
            string pattern = "^([A-Za-z]{2,8})$";
            //                "^" +            //represents; starting character of the string
            //                "(?=[A-Za-z])" + //represents; contain only alphabetic characters
            //                ".{2,8}" +       //represents; at least 2 characters and at most 8 characters
            //                "$";             //represents the end of the string

            //Find matches
            if (!Regex.Match(control.Text, pattern).Success)
            {
                //Console.WriteLine(name + " firstname must be between two to eight character long.", Title);
                throw new Exception(name + " must be between two to eight alphabetic character long.");
            }
            else
            {
                //Console.WriteLine(name + " is a match");
                return true;
            }
        }

        public static bool IsPhoneValid(Control control, string name)
        {
            //Validating user input with Regular Expression
            //Defining a regular expression pattern
            string pattern = "^0[0-9]{9}$";
            //or ^0\d{9}$
            //                "^" +         //represents; starting character of the string
            //                "(?=0)" +     //represents; starts with zero
            //                "(?=[0-9])" + //represents; contains only digits
            //                "{9}" +       //represents; contains 10 digits
            //                "$";          //represents the end of the string                
            //Find matches
            if (!Regex.Match(control.Text, pattern).Success)
            {
                control.Select();
                //Console.WriteLine(name + " phone number must start with a zero and have 9 digit afterwards no whitespace or special characters are allowed");
                throw new Exception(name + " must start with a zero and have 9 digit afterwards no whitespace or special characters are allowed.");
            }
            else
            {
                //Console.WriteLine(name + " is a match");
                return true;
            }
        }
    }
}
